## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> TRADUZIDO POR: DARK YT. THANKS MHANKBAR 
<p align="center">
<img src="https://media-giphy-com.cdn.ampproject.org/ii/w820/s/media.giphy.com/media/1g3A0gpaidxWcL9Mfo/giphy.gif" width="230" height="230"/>
</p>
<br>


 
</details>

### ATENÇÃO
DESEJA RE-CARREGAR O SCRIPT?  NÃO ALTERE O NOME !!!

## NOTA:>
NÃO VENDE / COMPRE O SCRIPT, ESTE SCRIPT É 100% GRATUITO PARA OS USUÁRIOS DO TERMUX
</div>

### FERRAMENTAS E MATERIAIS <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Prepare as ferramentas e materiais.
`` `bash
> 2 telefones celulares (1 para executar SC, 1 para ler o código QR sis)
> rede de internet rápida, cota +
> armazenamento adequado
> aplicativo whatsapp
> aplicativo termux
> café + cigarros KKKK;-;
```
INSTALAÇÃO:

> Se você não tiver o APK Termux, baixe-o na Playstore
> entre no apk termux e digite abaixo!
> termux-setup-storage
> pkg install git && pkg install tesseract && 
> apt update && apt upgrade
> git clone https://github.com/DarkZh/dark-bot
> cd dark-bot
> bash install.sh
> npm start
> Basta escanear o código qr e ... pronto
```

## CARACTERÍSTICAS  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">
| Criador de adesivos | Em destaque |
| :-----------: | :--------------------------------: |
|       ✅       | Enviar foto com legenda |
| ✅ | Responder uma foto |
| ✅ | Responder a um vídeo ou GIF |
| ✅ | Enviar vídeo ou GIF com legenda |
|                         |
|                 |
|       ✅        |   Obtenha um meme aleatório             |
|       ✅        |   Texto para fala                |
|       ✅        |   Recurso de escrita |
| ✅ | O que é esse anime |
| ✅ | Url2Img (captura de tela da Web) |
|       ✅        |   Simsimi		                |

| Group  |                     Feature               |
| :-----------: | :--------------------------------: |
|       ✅        |   Tagall/Mentionall member       |
|       ✅        |   expulsar menbros	             |
|       ✅        |   Adicionar Membros	             |
|       ✅        |   Obter lista de adms          |

| Owner Bot | Destaque           |
| :-----------: | :--------------------------------: |
|       ✅        |   Conjunto de prefixo                     |
|       ✅        |   Broadcast                      |
|       ✅        |   Limpar todos os chats                |

## Agradecimentos especiais para:
* [`adiwajshing/Baileys`](https://github.com/adiwajshing/Baileys)

## Grupo:
* [`WhatsApp`](https://chat.whatsapp.com/KTlC0MXi3WJChdQeps5flt)
### Donate
* [`Saweria`](OFF)
