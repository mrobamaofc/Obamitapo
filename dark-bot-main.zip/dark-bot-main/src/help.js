const help = (prefix) => {
	return `> *┏ ❣ *OBAMITA BOT* ❣
╿
┷┯ ☾ *Comandos* ☽
   ╽
   ┠❥ *.sticker: cria figurinha animadas ou normais*
   ┠❥ *.gtts: [linguagem] Texto* 
   ┠❥ *.wait: descubra o nome do anime basta enviar uma foto*
   ┠❥ *.tagall: marque todos do grupo* 
   ┠❥ *.linkgroup: pegue o link do grupo*
   ┠❥ *.sticker nobg: crie sticker removendo o seu fundo*
   ┠❥ *.toimg: converta sticker em foto*
   ┠❥ *.tsticker: converta txt em sticker*
   ┠❥ *.meme: imagem aleatória (não e em português)*
   ┠❥ *.memeindo: imagens aleatórias de meme [indo]*
   ┠❥ *.simi: modo interativo*
   ┠❥ *.piada: piadas aleatórias*
   ┠❥ *.gerarpe: gere dados pessoais aleatórios*
   ┠❥ *.simi: suas mensagem será respondidas por simi*
   ┠❥ *.ocr: pegue o txt na foto*
   ┠❥ *.url2img: busca o tipo da imagem*
   ┠❥ *.criador: dono do bot*
   ┠❥ *.gerarco: gere uma conta corrente aleatória*
   ┠❥ *.meme1: memes kkkkkkkkkkkkkkkkk*
   ┠❥ *.kick : remova uma pessoa do grupo*
   ┠❥ *.loli : enviar fotos de loli
   ┠❥*.clearall : limpe todas massagem do bot
   ┠❥*.bc: envie mensagem pra todos que usaram o bot
   ┠❥*.listadmins: todos os admdo grupo
   ┠❥*.clone : clone clone a foto de perfil
   ┠❥*.welcome : modo bem vindo do grupo
   ╰╼❥ leia os termos de uso do bot digitando o comando *.termos* DEVE LER!!.
}

exports.help = help


